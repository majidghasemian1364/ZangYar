package ir.zangyar.app
import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.*
import android.os.LocaleList
import java.util.Locale
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.*

class MainActivity:ComponentActivity(){
 private val calPerm=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(b:Bundle?){
  super.onCreate(b);if(checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED)calPerm.launch(Manifest.permission.READ_CALENDAR)
  setContent{MaterialTheme{
   var alarms by remember{mutableStateOf(AlarmStore.load(this))};var edit by remember{mutableStateOf<AlarmModel?>(null)}
   var add by remember{mutableStateOf(false)};var showSettings by remember{mutableStateOf(false)}
   fun save(l:List<AlarmModel>){alarms=l.sortedBy{it.hour*60+it.minute};AlarmStore.save(this,alarms);AlarmScheduler.all(this)}
   when{
    showSettings->SettingsScreen({showSettings=false})
    add||edit!=null->Editor(edit,{add=false;edit=null},{a->save(alarms.filter{it.id!=a.id}+a);add=false;edit=null})
    else->Home(alarms,{add=true},{edit=it},{a->save(alarms.map{x->if(x.id==a.id)x.copy(enabled=!x.enabled)else x)}),{save(alarms.filter{x->x.id!=it.id})},{showSettings=true})
   }
  }}
 }
}

@Composable fun Home(a:List<AlarmModel>,new:()->Unit,edit:(AlarmModel)->Unit,toggle:(AlarmModel)->Unit,del:(AlarmModel)->Unit,settings:()->Unit){
 Column(Modifier.fillMaxSize().padding(18.dp)){Text("زنگ‌یار",style=MaterialTheme.typography.headlineLarge)
  Row{Button(onClick=new){Text("+ زنگ")} ; Spacer(Modifier.width(8.dp));OutlinedButton(onClick=settings){Text("تنظیمات")}}
  LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(a,key={it.id}){x->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
   Text("%02d:%02d  %s".format(x.hour,x.minute,x.label),style=MaterialTheme.typography.titleLarge)
   Text(if(x.days.size==7)"هر روز" else "روزهای انتخاب‌شده: "+x.days.sorted().joinToString(","))
   Text(if(x.holidaysOff)"تعطیلات: خاموش"else"تعطیلات: روشن")
   Row{TextButton({edit(x)}){Text("ویرایش")};TextButton({toggle(x)}){Text(if(x.enabled)"خاموش"else"فعال")};TextButton({del(x)}){Text("حذف")}}
  }}}}
 }
}

@Composable fun Editor(initial:AlarmModel?,cancel:()->Unit,save:(AlarmModel)->Unit){
 val c=LocalContext.current;var h by remember{mutableIntStateOf(initial?.hour?:6)};var m by remember{mutableIntStateOf(initial?.minute?:30)}
 var en by remember{mutableStateOf(initial?.enabled?:true)};var hol by remember{mutableStateOf(initial?.holidaysOff?:true)}
 var label by remember{mutableStateOf(initial?.label?:"زنگ")};var vib by remember{mutableStateOf(initial?.vibrate?:true)}
 var dur by remember{mutableIntStateOf(initial?.durationSec?:60)};var snooze by remember{mutableIntStateOf(initial?.snoozeMin?:5)}
 var days by remember{mutableStateOf(initial?.days?:setOf(2,3,4,5))};var uri by remember{mutableStateOf(initial?.ringtoneUri?.let(Uri::parse))}
 val calendars=remember{CalendarReader.calendars(c)};var calId by remember{mutableStateOf(initial?.calendarId)}
 val pick=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->uri=r.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)}
 Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("تنظیم زنگ",style=MaterialTheme.typography.headlineMedium)
  OutlinedTextField(value=label,onValueChange={label=it},label={Text("نام")},singleLine=true)
  Row{Button({h=(h+1)%24}){Text("ساعت %02d".format(h))};Spacer(Modifier.width(6.dp));Button({m=(m+5)%60}){Text("دقیقه %02d".format(m))}}
  Row{Checkbox(en,{en=it});Text("فعال")};Row{Checkbox(hol,{hol=it});Text("در تعطیلات زنگ نزند")};Row{Checkbox(vib,{vib=it});Text("ویبره")}
  Text("روزهای فعال")
  Row{(1..7).forEach{d->FilterChip(days.contains(d),{days=if(days.contains(d))days-d else days+d},{Text(listOf("ی","د","س","چ","پ","ج","ش")[d-1])})}}
  Text("تقویم منبع")
  calendars.forEach{(id,n)->Row{RadioButton(calId==id,{calId=id});Text(n)}}
  OutlinedButton({pick.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply{putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,RingtoneManager.TYPE_ALARM);putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT,true);putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,uri)})}){Text("صدای زنگ: "+RingtoneHelper.title(c,uri))}
  Row{Text("مدت زنگ: $dur ثانیه");Button({dur=(dur+15).coerceAtMost(300)}){Text("+15")}}
  Row{Text("چرت: $snooze دقیقه");Button({snooze=(snooze+5).coerceAtMost(60)}){Text("+5")}}
  Row{OutlinedButton(cancel){Text("لغو")};Spacer(Modifier.width(8.dp));Button({save(AlarmModel(initial?.id?:System.currentTimeMillis().toInt(),h,m,en,days,hol,calId,uri?.toString(),label.ifBlank{"زنگ"},dur,vib,snooze))}){Text("ذخیره")}}
 }
}

@Composable fun SettingsScreen(back:()->Unit){
 val c=LocalContext.current
 var selected by remember { mutableStateOf(if(c.resources.configuration.locales[0].language=="en") "en" else "fa") }
 Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text(stringResource(ir.zangyar.app.R.string.settings),style=MaterialTheme.typography.headlineMedium)
  Text(stringResource(ir.zangyar.app.R.string.language))
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
   FilterChip(selected=="fa",{selected="fa";setLanguage(c,"fa")},{Text(stringResource(ir.zangyar.app.R.string.persian))})
   FilterChip(selected=="en",{selected="en";setLanguage(c,"en")},{Text(stringResource(ir.zangyar.app.R.string.english))})
  }
  Text(stringResource(ir.zangyar.app.R.string.calendar_source))
  Text("Calendar Provider / تقویم‌های قابل دسترس اندروید")
  Button(back){Text(stringResource(ir.zangyar.app.R.string.back))}
 }
}
fun setLanguage(c:Context,lang:String){
 val lm=c.getSystemService(android.app.LocaleManager::class.java)
 if(android.os.Build.VERSION.SDK_INT>=33) lm.applicationLocales=LocaleList.forLanguageTags(lang)
 else {
  val conf=c.resources.configuration
  conf.setLocale(Locale(lang))
  c.resources.updateConfiguration(conf,c.resources.displayMetrics)
 }
}

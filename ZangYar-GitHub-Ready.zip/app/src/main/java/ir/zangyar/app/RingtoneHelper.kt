package ir.zangyar.app
import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
object RingtoneHelper{
 fun title(c:Context,u:Uri?)=if(u==null)"پیش‌فرض آلارم" else RingtoneManager.getRingtone(c,u)?.getTitle(c)?:"زنگ انتخاب‌شده"
}

package ir.zangyar.app
import android.app.AlarmManager
import android.content.*
class BootReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){if(i.action in setOf(Intent.ACTION_BOOT_COMPLETED,Intent.ACTION_TIME_CHANGED,Intent.ACTION_TIMEZONE_CHANGED,AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED))AlarmScheduler.all(c)}
}

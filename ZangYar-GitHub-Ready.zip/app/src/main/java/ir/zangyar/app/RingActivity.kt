package ir.zangyar.app
import android.media.*
import android.net.Uri
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class RingActivity:ComponentActivity(){
 private var r:Ringtone?=null;private var v:Vibrator?=null;private var stopped=false
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val u=intent.getStringExtra("ringtoneUri")?.let(Uri::parse)?:RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
  r=RingtoneManager.getRingtone(this,u)?.apply{audioAttributes=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build();play()}
  v=getSystemService(Vibrator::class.java);if(intent.getBooleanExtra("vibrate",true))v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0,700,400,700),0))
  val sec=intent.getIntExtra("durationSec",60);Handler(Looper.getMainLooper()).postDelayed({stopAlarm()},sec*1000L)
  setContent{MaterialTheme{Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){
   Text(intent.getStringExtra("label")?:"زنگ‌یار",style=MaterialTheme.typography.headlineLarge);Spacer(Modifier.height(20.dp))
   Button(onClick={stopAlarm()}){Text("خاموش کردن")}
   Spacer(Modifier.height(8.dp));OutlinedButton(onClick={snooze()}){Text("چرت ${intent.getIntExtra("snoozeMin",5)} دقیقه‌ای")}
  }}}
 }
 private fun stopAlarm(){if(stopped)return;stopped=true;r?.stop();v?.cancel();finish()}
 private fun snooze(){val m=intent.getIntExtra("snoozeMin",5);val id=intent.getIntExtra("alarmId",-1)
  val am=getSystemService(AlarmManager::class.java);val pi=PendingIntent.getActivity(this,id+50000,Intent(this,RingActivity::class.java).apply{putExtras(intent)},
   PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+m*60000L,pi);stopAlarm()}
 override fun onDestroy(){r?.stop();v?.cancel();super.onDestroy()}
}

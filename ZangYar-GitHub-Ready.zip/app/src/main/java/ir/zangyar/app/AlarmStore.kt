package ir.zangyar.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
object AlarmStore {
    private const val P="zangyar"; private const val K="alarms"
    fun load(c:Context):MutableList<AlarmModel>{
        val a=JSONArray(c.getSharedPreferences(P,0).getString(K,"[]")?:"[]"); val out=mutableListOf<AlarmModel>()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val d=mutableSetOf<Int>(); val da=o.optJSONArray("days")
            if(da!=null)for(j in 0 until da.length())d+=da.getInt(j)
            if(d.isEmpty())d+=setOf(1,2,3,4,5)
            out+=AlarmModel(o.getInt("id"),o.getInt("hour"),o.getInt("minute"),
                o.optBoolean("enabled",true),d,o.optBoolean("holidaysOff",true),
                if(o.has("calendarId")&&!o.isNull("calendarId"))o.getLong("calendarId")else null,
                o.optString("ringtoneUri",null),o.optString("label","زنگ"),
                o.optInt("durationSec",60),o.optBoolean("vibrate",true),o.optInt("snoozeMin",5))
        }; return out
    }
    fun save(c:Context,list:List<AlarmModel>){
        val a=JSONArray(); list.forEach{ x->val d=JSONArray();x.days.sorted().forEach(d::put)
            a.put(JSONObject().apply{put("id",x.id);put("hour",x.hour);put("minute",x.minute);put("enabled",x.enabled)
                put("days",d);put("holidaysOff",x.holidaysOff);if(x.calendarId!=null)put("calendarId",x.calendarId)
                if(x.ringtoneUri!=null)put("ringtoneUri",x.ringtoneUri);put("label",x.label)
                put("durationSec",x.durationSec);put("vibrate",x.vibrate);put("snoozeMin",x.snoozeMin)})}
        c.getSharedPreferences(P,0).edit().putString(K,a.toString()).apply()
    }
}

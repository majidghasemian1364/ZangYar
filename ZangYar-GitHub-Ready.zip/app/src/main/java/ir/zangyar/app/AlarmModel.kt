package ir.zangyar.app
data class AlarmModel(
    val id:Int, val hour:Int, val minute:Int,
    val enabled:Boolean=true,
    val days:Set<Int>=setOf(1,2,3,4,5),
    val holidaysOff:Boolean=true,
    val calendarId:Long?=null,
    val ringtoneUri:String?=null,
    val label:String="زنگ",
    val durationSec:Int=60,
    val vibrate:Boolean=true,
    val snoozeMin:Int=5
)

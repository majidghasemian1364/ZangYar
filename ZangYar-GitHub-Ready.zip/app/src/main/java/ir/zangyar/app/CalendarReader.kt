package ir.zangyar.app
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.*
object CalendarReader {
    fun calendars(c:Context):List<Pair<Long,String>>{
        if(c.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED)return emptyList()
        val out=mutableListOf<Pair<Long,String>>()
        c.contentResolver.query(CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID,CalendarContract.Calendars.CALENDAR_DISPLAY_NAME),null,null,null)?.use{
            val id=it.getColumnIndex(CalendarContract.Calendars._ID);val n=it.getColumnIndex(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
            while(it.moveToNext())out+=it.getLong(id) to it.getString(n)
        };return out
    }
    fun key(ms:Long):String=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(ms))
    fun hasHolidayEvent(c:Context,ms:Long,calendarId:Long?):Boolean{
        if(c.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED)return false
        val d=Calendar.getInstance().apply{timeInMillis=ms;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        val s=d.timeInMillis;val e=s+86400000L
        val u=CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(s.toString()).appendPath(e.toString()).build()
        val p=arrayOf(CalendarContract.Instances.TITLE,CalendarContract.Instances.ALL_DAY,CalendarContract.Instances.CALENDAR_ID)
        c.contentResolver.query(u,p,null,null,null)?.use{
            val ti=it.getColumnIndex(CalendarContract.Instances.TITLE);val ai=it.getColumnIndex(CalendarContract.Instances.ALL_DAY);val ci=it.getColumnIndex(CalendarContract.Instances.CALENDAR_ID)
            while(it.moveToNext()){
                if(calendarId!=null&&it.getLong(ci)!=calendarId)continue
                val t=it.getString(ti).orEmpty().lowercase(Locale.getDefault())
                if(it.getInt(ai)==1&&listOf("تعطیل","تعطیلات","holiday","public holiday").any(t::contains))return true
            }
        };return false
    }
}

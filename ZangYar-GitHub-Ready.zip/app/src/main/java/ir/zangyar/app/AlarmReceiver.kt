package ir.zangyar.app
import android.content.*
class AlarmReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
  val id=i.getIntExtra("alarmId",-1);val a=AlarmStore.load(c).firstOrNull{it.id==id}?:return
  AlarmScheduler.schedule(c,a)
  c.startActivity(Intent(c,RingActivity::class.java).apply{addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
   putExtra("ringtoneUri",a.ringtoneUri);putExtra("label",a.label);putExtra("durationSec",a.durationSec);putExtra("vibrate",a.vibrate);putExtra("snoozeMin",a.snoozeMin);putExtra("alarmId",id)})
 }
}

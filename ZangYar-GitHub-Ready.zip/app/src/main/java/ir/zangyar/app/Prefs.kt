package ir.zangyar.app
import android.content.Context
import org.json.JSONArray
object Prefs {
    private const val P="zangyar"; private const val EX="exceptions"
    fun exceptions(c:Context):Set<String>{
        val a=JSONArray(c.getSharedPreferences(P,0).getString(EX,"[]")?:"[]")
        return buildSet { for(i in 0 until a.length()) add(a.getString(i)) }
    }
    fun saveExceptions(c:Context,s:Set<String>){
        val a=JSONArray(); s.sorted().forEach(a::put)
        c.getSharedPreferences(P,0).edit().putString(EX,a.toString()).apply()
    }
}

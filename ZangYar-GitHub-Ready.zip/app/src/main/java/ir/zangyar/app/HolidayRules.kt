package ir.zangyar.app
import java.util.*
object HolidayRules {
    // تعطیلات ثابت شمسی ایران. تعطیلات قمری/اعلامی باید از تقویم منبع یا فایل به‌روز تأمین شوند.
    private val fixed=listOf(
        1 to 1,2 to 1,3 to 1,4 to 1,5 to 1,6 to 1,
        13 to 1,14 to 1,15 to 1,22 to 11,29 to 11
    )
    // این جدول فقط نمونه محافظ است و جایگزین تقویم رسمی سالانه نیست.
    fun isFixedSolarHoliday(year:Int,month:Int,day:Int):Boolean =
        fixed.contains(month to day)
}

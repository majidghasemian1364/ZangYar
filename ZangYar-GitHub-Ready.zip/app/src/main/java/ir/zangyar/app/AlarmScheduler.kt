package ir.zangyar.app
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.*
object AlarmScheduler {
    private fun p(c:Context,id:Int)=PendingIntent.getBroadcast(c,id,Intent(c,AlarmReceiver::class.java).putExtra("alarmId",id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun schedule(c:Context,a:AlarmModel){
        cancel(c,a.id);if(!a.enabled||a.days.isEmpty())return
        val x=Calendar.getInstance();var guard=0
        while(guard++<370){
            val dow=x.get(Calendar.DAY_OF_WEEK)
            x.set(Calendar.HOUR_OF_DAY,a.hour);x.set(Calendar.MINUTE,a.minute);x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0)
            val key=CalendarReader.key(x.timeInMillis)
            val excluded=Prefs.exceptions(c).contains(key)
            val holiday=a.holidaysOff&&(excluded||CalendarReader.hasHolidayEvent(c,x.timeInMillis,a.calendarId))
            if(a.days.contains(dow)&&x.timeInMillis>System.currentTimeMillis()&&!holiday)break
            x.add(Calendar.DAY_OF_YEAR,1)
        }
        val am=c.getSystemService(AlarmManager::class.java)
        if(android.os.Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms())return
        val pi=p(c,a.id);am.setAlarmClock(AlarmManager.AlarmClockInfo(x.timeInMillis,pi),pi)
    }
    fun cancel(c:Context,id:Int)=c.getSystemService(AlarmManager::class.java).cancel(p(c,id))
    fun all(c:Context)=AlarmStore.load(c).forEach{if(it.enabled)schedule(c,it)else cancel(c,it.id)}
}
